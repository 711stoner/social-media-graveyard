const els = {
  statusDot: document.getElementById("statusDot"),
  statusText: document.getElementById("statusText"),
  accountText: document.getElementById("accountText"),
  postCount: document.getElementById("postCount"),
  snapshotCount: document.getElementById("snapshotCount"),
  scanBtn: document.getElementById("scanBtn"),
  saveBtn: document.getElementById("saveBtn"),
  exportBtn: document.getElementById("exportBtn")
};

let currentSnapshot = null;

function setStatus(text, type = "") {
  els.statusText.textContent = text;
  els.statusDot.className = ("dot " + type).trim();
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

async function requestScan(tabId) {
  try {
    return await chrome.tabs.sendMessage(tabId, { type: "THREADS_BACKUP_SCAN" });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/content.js"]
    });
    return chrome.tabs.sendMessage(tabId, { type: "THREADS_BACKUP_SCAN" });
  }
}

async function refreshSavedCount() {
  const result = await chrome.storage.local.get("threadsBackupSnapshots");
  const snapshots = result.threadsBackupSnapshots || [];
  els.snapshotCount.textContent = snapshots.length;
}async function scanCurrentPage() {
  setStatus("正在读取 Threads 页面…");
  els.scanBtn.disabled = true;

  try {
    const tab = await getActiveTab();
    if (!tab?.url || !/^https:\/\/(www\.)?threads\.(com|net)\//.test(tab.url)) {
      throw new Error("请先打开 Threads 主页");
    }

    const pageUrl = new URL(tab.url);
    if (!/^\/@[^/]+\/?$/.test(pageUrl.pathname)) {
      throw new Error("请打开你自己的 Threads 个人主页后再扫描");
    }

    const response = await requestScan(tab.id);
    if (!response?.ok) throw new Error(response?.error || "页面读取失败");

    currentSnapshot = response.data;
    const username = currentSnapshot.profile.username;
    els.accountText.textContent = username ? "@" + username : currentSnapshot.profile.url;
    els.postCount.textContent = currentSnapshot.visibleItems.length;
    els.saveBtn.disabled = false;
    els.exportBtn.disabled = false;
    setStatus("已连接当前 Threads 页面", "ok");
  } catch (error) {
    currentSnapshot = null;
    els.saveBtn.disabled = true;
    els.exportBtn.disabled = true;
    setStatus(error.message || "无法读取当前页面", "error");
  } finally {
    els.scanBtn.disabled = false;
  }
}async function saveSnapshot() {
  if (!currentSnapshot) return;

  const result = await chrome.storage.local.get("threadsBackupSnapshots");
  const snapshots = result.threadsBackupSnapshots || [];
  snapshots.push({
    ...currentSnapshot,
    savedAt: new Date().toISOString()
  });

  await chrome.storage.local.set({ threadsBackupSnapshots: snapshots });
  await refreshSavedCount();
  setStatus("快照已保存在浏览器本地", "ok");
}

function exportJson() {
  if (!currentSnapshot) return;

  const username = currentSnapshot.profile.username || "threads";
  const blob = new Blob(
    [JSON.stringify(currentSnapshot, null, 2)],
    { type: "application/json;charset=utf-8" }
  );
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = username + "-threads-snapshot.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}els.scanBtn.addEventListener("click", scanCurrentPage);
els.saveBtn.addEventListener("click", saveSnapshot);
els.exportBtn.addEventListener("click", exportJson);

refreshSavedCount();
scanCurrentPage();