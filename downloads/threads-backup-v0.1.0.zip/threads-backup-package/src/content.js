function cleanText(value = "") {
  return value.replace(/\s+/g, " ").trim();
}

function getProfileMeta() {
  const match = location.pathname.match(/^\/@([^/]+)/);
  const ogTitle = document.querySelector('meta[property="og:title"]')?.content || "";
  const ogDescription = document.querySelector('meta[property="og:description"]')?.content || "";
  const ogImage = document.querySelector('meta[property="og:image"]')?.content || "";

  return {
    url: location.href,
    username: match ? match[1] : null,
    title: cleanText(ogTitle || document.title),
    description: cleanText(ogDescription),
    avatarUrl: ogImage || null,
    capturedAt: new Date().toISOString()
  };
}

function findUsefulContainer(anchor) {
  let node = anchor;
  for (let i = 0; i < 7 && node?.parentElement; i += 1) {
    node = node.parentElement;
    const text = cleanText(node.innerText || "");
    if (text.length >= 20 && text.length <= 2200) return node;
  }
  return anchor.parentElement;
}function collectVisibleItems() {
  const username = getProfileMeta().username;
  if (!username) return [];

  const anchors = [...document.querySelectorAll('a[href*="/post/"]')]
    .filter((anchor) => {
      try {
        const url = new URL(anchor.href, location.origin);
        return url.pathname.startsWith("/@" + username + "/post/");
      } catch {
        return false;
      }
    });
  const seen = new Set();
  const items = [];

  for (const anchor of anchors) {
    const url = new URL(anchor.href, location.origin).href.split("?")[0];
    if (seen.has(url)) continue;
    seen.add(url);

    const container = findUsefulContainer(anchor);
    const text = cleanText(container?.innerText || anchor.innerText || "");
    const images = [...(container?.querySelectorAll("img") || [])]
      .map((img) => img.currentSrc || img.src)
      .filter(Boolean)
      .slice(0, 8);

    items.push({
      url,
      text: text.slice(0, 2200),
      images,
      capturedAt: new Date().toISOString()
    });
  }

  return items.slice(0, 100);
}

function buildSnapshot() {
  return {
    schemaVersion: 1,
    source: "threads-web-visible-page",
    profile: getProfileMeta(),
    visibleItems: collectVisibleItems()
  };
}if (!globalThis.__THREADS_BACKUP_LISTENER_INSTALLED__) {
  globalThis.__THREADS_BACKUP_LISTENER_INSTALLED__ = true;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "THREADS_BACKUP_SCAN") {
      try {
        sendResponse({ ok: true, data: buildSnapshot() });
      } catch (error) {
        sendResponse({ ok: false, error: error.message });
      }
    }
    return true;
  });
}